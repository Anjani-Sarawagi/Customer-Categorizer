![alt text](https://ineuron.ai/images/ineuron-logo.png)

# Assignment for Customer Segmentation Project

1. We have used logistic regression for the project as in notebooks we can clearly see that it os giving higher accuracy amongst other algorithms. Now you have to use any other algorithm and that should be performing better than logistic regression. You can use hyperparameter tuning to tune the models and use that model in this project.
2. For dimensionality reduction, in data clustering component, we have used PCA. Your task is to replace PCA with LDA in this project and make it run.
3. For CICD, we have used github actions. You are supposed to use Circle CI for this project.
4. We hace used mongodb here as a database. Your task is to use cassandra for this project.
5. Azure is used to deploy this project. Your task is to use AWS to deploy this project.
