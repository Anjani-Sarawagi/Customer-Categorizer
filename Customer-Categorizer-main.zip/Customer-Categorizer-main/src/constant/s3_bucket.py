TRAINING_BUCKET_NAME = "customer-segmentation-bucket"
PREDICTION_BUCKET_NAME = "sensor-datasource"
